def selection_sort_descend_trace(list):
    n = len(list)
    for i in range(n-1):
        maxindex = i
        for j in range(i + 1, n):
            if list[j] > list[maxindex]:
                maxindex = j
        list[i], list[maxindex] = list[maxindex], list[i]
        print(f'{" ".join(map(str, list))} ')

if __name__ == "__main__":
    numbers = list(map(int, input().split()))
    selection_sort_descend_trace(numbers)
