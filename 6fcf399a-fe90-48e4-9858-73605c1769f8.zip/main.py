def get_age():
    age = int(input())
    if age < 18:
        raise ValueError("Invalid age.")
    elif age > 75:
        raise ValueError("Invalid age.")
    else:
        return age

def fat_burning_heart_rate(age):
    heart_rate = float(0.7 * (220 - age))
    return heart_rate

if __name__ == "__main__":
    try:
        age = get_age()
        heartrate = fat_burning_heart_rate(age)
        print(f'Fat burning heart rate for a {age} year-old: {heartrate} bpm')
    except ValueError as excpt:
        print(excpt)
        print(f'Could not calculate heart rate info.\n')

