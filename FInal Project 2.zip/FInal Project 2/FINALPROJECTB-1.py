# Tebello Rose - 2165470
import csv
majorslistfile = 'StudentsMajorsList.csv'
majors = []
with open(majorslistfile, 'r', newline='') as MajorList:
    reader = csv.reader(MajorList)
    data = list(reader)
    majors.extend(data)
gpalistfile = 'GPAList.csv'
gpas = []
with open(gpalistfile, 'r', newline='') as GPAs:
    reader = csv.reader(GPAs)
    data = list(reader)
    gpas.extend(data)
graduationlistfile = 'GraduationDatesList.csv'
graddates = []
with open(graduationlistfile, 'r', newline='') as Grad:
    reader = csv.reader(Grad)
    data = list(reader)
    graddates.extend(data)

all_data = []
student_info = {}
# The above creates an empty for future use and a dictionary to contain all student info
for id, lastname, firstname, major, da in majors:
    student_info[id] = {'Last Name': lastname, 'First Name': firstname, 'Major': major, 'DA': da}
# This initializes the dictionary with the values from the first list
for id, gpa in gpas:
    if id in student_info:
        student_info[id]['gpa'] = gpa
# This adds the gpa values to their corresponding student id
for id, graddate in graddates:
    if id in student_info:
        student_info[id]['Graduation Date'] = graddate
# This adds the graduation date values to the corresponding student id
for id, info in student_info.items():
    major = info['Major']
    first_name = info['First Name']
    last_name = info['Last Name']
    GPAverage = info.get('gpa', None)
    date = info.get("Graduation Date", None)
    DA = info.get("DA", None)
    all_data.append((id, major, first_name, last_name, GPAverage, date, DA))
# This puts all of the data together into a tuple with no duplications

for info in all_data:
    print()


def singlequery(student_info, major, gpa):
    matches = []
    for id, info in student_info.items():
        avg = info.get("GPAverage", None)
        majorname = info.get("Major", None)
        if majorname == major and float(avg) >= gpa-0.1 and float(avg) <= gpa+0.1 :
            if info.get("DA", None) != 'Y':
                matches.append((id, info))
    return matches

def students_by_gpa(student_info, major, target_gpa, threshold):
    students = []
    for id, info in student_info.items():
        if info['Major'] == major and abs(info['GPAverage'] - target_gpa) <= threshold:
            students.append((id, info))
    return students

def find_closest_student(student_info, major, target_gpa):
    c_student = None
    min_difference = float('inf')
    for id, info in student_info.items():
        if info['Major'] == major and info.get('date', None) is None and info.get('DA', None) is None:
            difference = abs(info['GPAverage'] - target_gpa)
            if difference < min_difference:
                c_student = ((id, info))
                min_difference = difference
    return c_student


def user_query():
  #  Continuously query the user until 'q' is entered.
    while True:
        user_input = input("Enter major and GPA separated by space (enter 'q' to quit): ").strip()
        if user_input.lower() == 'q':
            break
        user_input = user_input.split()
        if len(user_input) != 2:
            print("Invalid input. Please provide major and GPA.")
            continue
        major = user_input[0]
        try:
            gpa = float(user_input[1])
        except ValueError:
            print("Invalid GPA. Please provide a numeric value.")
            continue
        process_query(major, gpa)

def process_query(major, gpa):

    # Process the user query and print results.
    try:
        # Query student records
        result = query_student(student_info, major, gpa)

        # Print results
        if len(result) == 0:
            print("No such student.")
        elif len(result) > 1:
            print("More than one student found with the same major and GPA.")
        else:
            id, info = result[0]
            print("Your student(s):")
            print("Student ID:", id)
            print("Last Name:", info['last_name'])
            print("First Name:", info['first_name'])
            print("GPA:", info['GPAverage'])

    except Exception as e:
        print("An error occurred:", e)


user_input = input("Enter student major and GPA").split()
if len(user_input) != 2:
    print("Invalid input, please input Major and GPA")
else:
    major = " ".join(word for word in user_input[:-1] if word.isalpha())
    gpa = user_input[-1]




results = singlequery(student_info, major, gpa)

id, info = results[0]
if len(results) == 0:
    print("No such student")
elif info[DA] == "Y":
    print('An error has occured.')
else:
    id, info = results[0]
    print(f'Your student(s): {id}, {info[first_name], info[last_name], info[GPAverage]}')


close_students = students_by_gpa(student_info, major, gpa, 0.1)
if not close_students:
    closest_student = find_closest_student(student_info, major, gpa)
    if closest_student:
        print("\nClosest student within the requested major:")
        print("Student ID:", closest_student[0])
        print("Last Name:", closest_student[1]['last_name'])
        print("First Name:", closest_student[1]['first_name'])
        print("GPA:", closest_student[1]['GPAverage'])
    else:
        print("\nNo student within the requested major.")
    for id, info in close_students:
        if info.get("date", None) is None and info.get("DA", None) is None:
            print(f'Student ID: {id}, Name: {info["first_name"]} {info["last_name"]}, GPA: {info["GPAverage"]}')
